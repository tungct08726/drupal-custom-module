<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VoucherUserPost extends Model
{
    protected $table="voucher_user_post";
    protected $fillable=[
        'user_id',
        'post_id',
        'voucher_code'
    ];
}
