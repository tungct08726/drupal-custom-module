<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table="post";
    protected $fillable=[
    	'name',
        'slug',
        'thumb',
    	'description',
    	'content',
    	'active',
        'voucher_enable',
        'voucher_quantity',
    ];
    public function categories()
    {
        return $this->belongsToMany(Category::class, 'category_posts');
    }


}
