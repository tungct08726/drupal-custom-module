<?php

namespace App\Helpers;
use Illuminate\Support\Facades\Session;

class Helper
{
	# Admin

	public static function cate($cates, $parent_id = 0, $char = ''){
		$html='';
		foreach ($cates as $key => $value) {
			if ($value->parent_id == $parent_id) {
				$html .='
					<tr>
						<td>'. $value->id .'</td>
						<td>'. $char . $value->name .'</td>
						<td>'. self::active($value->active) .'</td>
						<td>'. $value->updated_at .'</td>
						<td>
							<a class="btn btn-primary btn-sm" href="/admin/category/edit/'.$value->id.'"><i class="fas fa-edit"></i>
							</a>
							<a class="btn btn-danger btn-sm" href="#" 
							onclick="removeRow('. $value->id .', \'/admin/category/destroy\')">
								<i class="fas fa-trash"></i>
							</a>
						</td>
					</tr>
				';
				//xóa đi danh mục đã hiện ra trong mảng menus
				unset($cates[$key]);
				//tìm xem danh mục nó có con không, có thì thêm vào
				$html .= self::cate($cates, $value->id, '-->');
			}
		}
		return $html;
	}

	public static function post($posts, $parent_id = 0, $char = ''){
		$html='';
		foreach ($posts as $key => $value) {
			if ($value->parent_id == $parent_id) {
				$html .='
					<tr>
						<td>'. $value->id .'</td>
						<td>'. $char . $value->name .'</td>
						<td><img src="'. $value->thumb .'" width="200"></td>
						<td>'. self::active($value->active) .'</td>
						<td>'. $value->updated_at .'</td>
						<td>
							<a class="btn btn-primary btn-sm" href="/admin/post/edit/'.$value->id.'"><i class="fas fa-edit"></i>
							</a>
							<a class="btn btn-danger btn-sm" href="#" 
							onclick="removeRow('. $value->id .', \'/admin/post/destroy\')">
								<i class="fas fa-trash"></i>
							</a>
						</td>
					</tr>
				';
				//xóa đi danh mục đã hiện ra trong mảng menus
				unset($posts[$key]);
				//tìm xem danh mục nó có con không, có thì thêm vào
				$html .= self::post($posts, $value->id, '-->');
			}
		}
		return $html;
	}

	public static function product($products){
		$html='';
		foreach ($products as $key => $value) {
				$html .='
					<tr>
						<td>'. $value->id .'</td>
						<td>'. $value->name .'</td>
						<td>'. $value->menu['name'] .'</td>
						<td><img src="'. $value->thumb .'" width="200"></td>						
						<td>'. self::active($value->active) .'</td>
						<td>'. $value->updated_at .'</td>
						<td>
							<a class="btn btn-primary btn-sm" href="/admin/products/edit/'.$value->id.'"><i class="fas fa-edit"></i>
							</a>
							<a class="btn btn-danger btn-sm" href="#" 
							onclick="removeRow('. $value->id .', \'/admin/products/destroy\')">
								<i class="fas fa-trash"></i>
							</a>
						</td>
					</tr>
				';
				//xóa đi danh mục đã hiện ra trong mảng menus
				unset($products[$key]);
		}
		return $html;
	}

	public static function slider($sliders){
		$html='';
		foreach ($sliders as $key => $value) {
				$html .='
					<tr>
						<td>'. $value->id .'</td>
						<td>'. $value->name .'</td>
						<td>'. $value->url .'</td>
						<td><img src="'. $value->thumb .'" width="200"></td>						
						<td>'. self::active($value->active) .'</td>
						<td>'. $value->updated_at .'</td>
						<td>
							<a class="btn btn-primary btn-sm" href="/admin/sliders/edit/'.$value->id.'"><i class="fas fa-edit"></i>
							</a>
							<a class="btn btn-danger btn-sm" href="#" 
							onclick="removeRow('. $value->id .', \'/admin/sliders/destroy\')">
								<i class="fas fa-trash"></i>
							</a>
						</td>
					</tr>
				';
				//xóa đi danh mục đã hiện ra trong mảng menus
				unset($sliders[$key]);
		}
		return $html;
	}


	public static function active($active = 0) : string
	{
		return $active == 0 ? '<span class="btn btn-danger btn-xs">NO</span>':
								'<span class="btn btn-success btn-xs">YES</span>';
	}


######
    # View



	public static function menuHeader($data, $parent_id = 0){
		$html='';
		foreach ($data as $key => $value) {
			if ($value->parent_id == $parent_id) {
				$html .='
					<li>
						<a href="/danh-muc/'.$value->id.'-'. $value->slug .'.html">
							'.$value->name.'
						</a>';
				unset($data[$key]);		
				if (self::isChild($data,$value->id)) 
				{
					$html .= '<ul class="sub-menu">';
					$html .= self::menuHeader($data,$value->id);
					$html .= '</ul>';
				}		
				//xóa đi danh mục đã hiện ra trong mảng menus
				
				//tìm xem danh mục nó có con không, có thì thêm vào
				$html .= '</li>';
			}
		}
		return $html;
	}
	public static function menuHeaderMobile($data, $parent_id = 0){
		$html='';
		foreach ($data as $key => $value) {
			if ($value->parent_id == $parent_id) {
				$html .='
					<li>
						<a href="/danhmuc/'.$value->id.'-'. $value->slug .'.html">
							'.$value->name.'
						</a>';
				unset($data[$key]);		
				if (self::isChild($data,$value->id)) 
				{
					$html .= '<ul class="sub-menu-m">';
					$html .= self::menuHeader($data,$value->id);
					$html .= '</ul>
					    <span class="arrow-main-menu-m">
		            	<i class="fa fa-angle-right" aria-hidden="true"></i>
		          		</span>
					';
				}		
				//xóa đi danh mục đã hiện ra trong mảng menus
				
				//tìm xem danh mục nó có con không, có thì thêm vào
				$html .= '</li>';
			}
		}
		return $html;
	}

	public static function isChild($data,$id){
		foreach ($data as $key => $value) {
			if ($value->parent_id == $id) {
				return true;
			}
			return false;
		}
	}

	public static function price($price = 0, $priceSale = 0){
		if ($priceSale !=0) {
			return number_format($priceSale);
		}
		if ($price !=0) {
			return number_format($price);
		}		
		return '<a href="/lien-he.html">Contact</a>';
	}

}