<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table="products";
    protected $fillable=[
    	'name',
    	'thumb',
        'photos',
    	'description',
    	'content',
    	'menu_id',
    	'price',
    	'price_sale',
    	'active',
    	'slug',
    ];
protected $casts = [
        'photos' => 'array'
    ];
    public function menu(){
        return $this->hasOne(Menu::class, 'id', 'menu_id');
    }


}
