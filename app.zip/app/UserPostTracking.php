<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPostTracking extends Model
{
    protected $table="user_post_tracking";
    protected $fillable=[
        'user_id',
        'post_id',
        'read_count'
    ];
}
