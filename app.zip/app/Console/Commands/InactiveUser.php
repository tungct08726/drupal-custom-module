<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\User;
use App\UserPostTracking;
use App\Post;
use App\Notifications\NotifyInactiveUser;

use Illuminate\Support\Carbon;

class InactiveUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'email:inactiveUser';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send mail to in active user';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $limit = Carbon::now()->subDay(1);
        $inactive_user = User::where('last_login','<=',$limit)->where('role','<>','admin')->get();
            /*
            $user_post_tracking = UserPostTracking::select('post_id')->where('user_id',$user->id)->get();
            $post = Post::select('id')->get();
            $arr1= [];
            $arr2= [];
            foreach ($user_post_tracking as $key => $value) {
                $arr1[$value->post_id]=$value->post_id;
            }
            foreach ($post as $key => $value) {
                $arr2[$value->id]=$value->id;
            }
            $arr = array_diff_key($arr2, $arr1);
            $p=Post::whereIn('id',$arr)->get();
            */

            //dd($p->toArray());
        foreach ($inactive_user as $key => $user) {

            $user->notify(new NotifyInactiveUser());
        }
    }
}
