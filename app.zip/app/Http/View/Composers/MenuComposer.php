<?php

namespace App\Http\View\Composers;

use App\Repositories\UserRepository;
use Illuminate\View\View;

use App\Category;

class MenuComposer
{

    protected $users;


    public function __construct()
    {
    }


    public function compose(View $view)
    {
        $menuHeader = Category::where('active', 1)->get();
        $view->with('menuHeader',$menuHeader);
    }
}