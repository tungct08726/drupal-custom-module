<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Services\Product\ProductService;

use App\Http\Services\Cart\CartService;

use App\Product;


use Illuminate\Support\Facades\Session;
class CartController extends Controller
{
    protected $product;
    protected $cart;
    public function __construct(CartService $cart, ProductService $product){
        $this->cart = $cart; 
        $this->product = $product; 
    }

    public function index(Request $request){
    	$result= $this->cart->create($request);
    	if ($result == false) {
    		return redirect()->back();
    	}
    	return redirect('/gio-hang');
    }

    public function update(Request $request){
    	//dd($request->all());
    	$result= $this->cart->update($request);
    	if ($result == false) {
    		return redirect()->back();
    	}
    	return redirect('/gio-hang');
    }

    public function addCart(Request $request){
    	//dd($request->all());
    	$result= $this->cart->addCart($request);
    	return redirect()->back();
    }

    public function show(){
    	
    	$products= $this->cart->getProduct();
    	
    	
    	$carts= Session::get('cart');
    	//dd($carts);
    	return view('cart.list',[
    		'title' => 'Giỏ Hàng',
    		'carts' => $carts,
    		'products' =>$products
    	]);
    }
    public function remove($id =0){
    	$result= $this->cart->remove($id);
    	if ($result == false) {
    		return redirect()->back();
    	}
    	return redirect('/gio-hang');    	
    }
}
