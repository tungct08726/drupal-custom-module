<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Services\Category\CategoryService;
use App\Http\Services\Product\ProductService;

use App\Category;
class CategoryHTMLController extends Controller
{

    protected $category;
    protected $product;

    public function __construct(CategoryService $category, ProductService $product){
        $this->category = $category; 
        $this->product = $product; 
    }



    public function index(Request $request, $id, $slug = '')
    {
        //dd($id);
        $category = $this->category->getId($id);
        $post = $this->category->getProduct($category,$request);

        return view('category',[
            'title' => $category->name,
            'post' =>$post,
            'category' =>$category,
        ]);
    }
    public function loadProduct(Request $request)
    {
        $page= $request->input('page',0);
        $result= $this->product->load($page);

        if (count($result) != 0) {
            $html = view('product.product_list',['products'=>$result])->render();
            return response()->json([
                'html' => $html
            ]);              
        }
        return response()->json([
            'html' => ''
        ]);          
    }

}
