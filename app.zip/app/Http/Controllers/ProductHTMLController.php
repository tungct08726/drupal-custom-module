<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Services\Menu\MenuService;
use App\Http\Services\Product\ProductService;

use App\Menu;

use App\Product;
class ProductHTMLController extends Controller
{

    protected $menu;
    protected $product;

    public function __construct(MenuService $menu, ProductService $product){
        $this->menu = $menu; 
        $this->product = $product; 
    }



    public function index(Request $request, $id, $slug = '')
    {
        $product = $this->product->getProductDetail($id,$request);
        if ($product->photos == null) {
            $slide = [];
        }    
        else{
            $slide= json_decode($product->photos);
        }    
        


        $menu_id = $product->menu['id'];
        $relate = $this->product->getProductRelate($id,$request,$menu_id);
        return view('product_detail',[
            'title' => $product->name,
            'product' =>$product,
            'slide'=>$slide,
            'relate' => $relate
        ]);
    }

}
