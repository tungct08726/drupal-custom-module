<?php

namespace App\Http\Controllers\Admin;
use App\Http\Services\Slider\SliderService;
use App\Http\Requests\Slider\CreateFormRequest;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Slider;

class SliderController extends Controller
{
	protected $sliderService;

	public function __construct(SliderService $sliderService){
		$this->sliderService = $sliderService; 
	}

    public function create(){
    	return view('admin.slider.add',[
    		'title'=> "Thêm Sản Phẩm"
    	]);
    }
    public function show(Slider $slider){
    	return view('admin.slider.edit',[
    		'title'=> "Chỉnh Sửa : ".$slider->name,
    		'slider'=>$slider
    	]);
    }

    public function store(CreateFormRequest $request){
    	$result = $this->sliderService->create($request);
    	return redirect()->back();
    }

    public function update(Slider $slider, CreateFormRequest $request){
    	$result = $this->sliderService->update($request,$slider);
    	return redirect()->back();
    }

    public function destroy(Request $request){
    	$result = $this->sliderService->destroy($request);
    	if ($result) {
    		return response()->json([
    			'error' => false,
    			'message'=> '~ Xóa Xong Rồi ~'
    		]);
    	}
    	return response()->json([
    		'error' => true
    	]); 
    }

    public function index(){
    	return view('admin.slider.list',[
    		'title'=> "Danh Sách Slide",
    		'sliders'=>$this->sliderService->getAll()
    	]);
    }

}
