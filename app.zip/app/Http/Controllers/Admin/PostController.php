<?php

namespace App\Http\Controllers\Admin;
use App\Http\Services\Post\PostService;
use App\Http\Services\Category\CategoryService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Post\CreateFormRequest;
use App\Post;
use App\Category;
class PostController extends Controller
{
	protected $postService;
    protected $cateService;
	public function __construct(CategoryService $cateService, PostService $postService){
		$this->postService = $postService; 
        $this->cateService = $cateService; 
	}

    public function create(){
    	return view('admin.post.add',[
    		'title'=> "Thêm",
            'category'=>$this->cateService->getAll()
    	]);
    }
    public function show(Post $post){
        $post_category=$post->categories()->get();
        //dd($post_category->toArray());
        $post_cate=array();
        foreach ($post_category as $key => $value) {
            $post_cate[$value->id]=$value;
        }
        //dd($post_cate);
    	return view('admin.post.edit',[
    		'title'=> "Chỉnh Sửa ".$post->name,
    		'post'=>$post,
            'category'=>$this->cateService->getAll(),
            'post_cate'=>$post_cate
    	]);
    }

    public function store(CreateFormRequest $request){
        //dd($request->input('category'));
    	$result = $this->postService->create($request);
    	return redirect()->back();
    }

    public function update(Post $post, CreateFormRequest $request){
      
    	$result = $this->postService->update($request, $post);
    	return redirect('/admin/post/list');
    }

    public function destroy(Request $request){
    	$result = $this->postService->destroy($request);
    	if ($result) {
    		return response()->json([
    			'error' => false,
    			'message'=> ' Complete'
    		]);
    	}
    	return response()->json([
    		'error' => true
    	]); 
    }

    public function index(Request $request){
        $category= Category::where('active',1)->get();
        //dd($this->postService->getAll($request));
    	return view('admin.post.list',[
    		'title'=> "Danh Sách",
            'category'=>$category,
    		'posts'=>$this->postService->getAll($request)
    	]);
    }

}
