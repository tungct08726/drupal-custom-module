<?php

namespace App\Http\Controllers\Admin;
use App\Http\Services\Category\CategoryService;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Category\CreateFormRequest;
use App\Category;

class CategoryController extends Controller
{
	protected $cateService;

	public function __construct(CategoryService $cateService){
		$this->cateService = $cateService; 
	}

    public function create(){
    	return view('admin.category.add',[
    		'title'=> "Thêm Danh Mục",
    		'cates'=>$this->cateService->getParent()
    	]);
    }
    public function show(Category $cate){
    	return view('admin.category.edit',[
    		'title'=> "Chỉnh Sửa danh Mục ".$cate->name,
    		'cate'=>$cate,
    		'cates'=>$this->cateService->getParent()
    	]);
    }

    public function store(CreateFormRequest $request){
    
    	$result = $this->cateService->create($request);
    	return redirect()->back();
    }

    public function update(Category $cate, CreateFormRequest $request){
      
    	$result = $this->cateService->update($request, $cate);
    	return redirect('/admin/category/list');
    }

    public function destroy(Request $request){
    	$result = $this->cateService->destroy($request);
    	if ($result) {
    		return response()->json([
    			'error' => false,
    			'message'=> '~ Xóa Xong Rồi ~'
    		]);
    	}
    	return response()->json([
    		'error' => true
    	]); 
    }

    public function index(){
    	return view('admin.category.list',[
    		'title'=> "Danh Sách Danh Mục",
    		'cates'=>$this->cateService->getAll()
    	]);
    }

}
