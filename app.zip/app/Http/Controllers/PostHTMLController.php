<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Services\Category\CategoryService;
use App\Http\Services\Product\ProductService;

use Illuminate\Support\Facades\Auth;

use App\Post;
use App\UserPostTracking;
use App\VoucherUserPost;
use App\User;
class PostHTMLController extends Controller
{

    protected $category;
    protected $product;

    public function __construct(CategoryService $category, ProductService $product){
        $this->category = $category; 
        $this->product = $product; 
    }



    public function index(Request $request, $id, $slug = '')
    {
        
        $post= Post::where('id',$id)->firstOrFail();
        $category=$post->categories()->get();
        
        if (Auth::check()) {
            $user_id = Auth::user()->id;
            $user_post = UserPostTracking::where('user_id',$user_id)->where('post_id',$id)->first();
            
            if ($user_post == null) {
                $data = UserPostTracking::create([
                    'user_id' => $user_id,
                    'post_id' => $id,
                    'read_count' => 1,
                ]);           
            }
            else{
                $read_count= $user_post->read_count;
                $user_post->read_count = $read_count + 1;
                $user_post->save();  
                
            }    
        }

        return view('post_detail',[
            'title' => $post->name,
            'post' =>$post,
            'category' =>$category,
        ]); 
    }

    public function getVoucher(Request $request){
        $post = Post::where('id',$request->input('post_id'))->firstOrFail();

        $user = User::select('id')->where('id',$request->input('user_id'))->firstOrFail();

        $checkVoucher = VoucherUserPost::where('user_id',$request->input('user_id'))
        ->where('post_id',$request->input('post_id'))->first();
        
        if($checkVoucher){
           return response()->json([
            'error' => 'You have take voucher for this post already'
            ]); 
        }
        else{
            if ($post->voucher_enable != 1) {
                return response()->json([
                    'error' => 'Sorry this post is not enable to give voucher anymore'
                ]);
            }
            else{
                if ($post->voucher_quantity <= 0) {
                    return response()->json([
                        'error' => 'Sorry this post is out number of voucher to give'
                    ]);
                }
                else if($post->voucher_quantity >= 1){

                    $voucher_code = 'GXAWEW_'.$user->id.'MNZVX'.$post->id;
                    ##
                    $post->voucher_quantity = $post->voucher_quantity - 1;
                    if ($post->voucher_quantity == 0) {
                        $post->voucher_enable = 0;
                    }
                    $post->save();
                    ##
                    VoucherUserPost::create([
                        'user_id' => (int) $user->id,
                        'post_id' => (int) $post->id,
                        'voucher_code' => (string) $voucher_code,
                    ]);     
                    ##
                    return response()->json([
                        'voucher' => 'Here is your : '.$voucher_code
                    ]); 
                }
            }
        }
    }

    public function loadProduct(Request $request)
    {
        $page= $request->input('page',0);
        $result= $this->product->load($page);

        if (count($result) != 0) {
            $html = view('product.product_list',['products'=>$result])->render();
            return response()->json([
                'html' => $html
            ]);              
        }
        return response()->json([
            'html' => ''
        ]);          
    }

}
