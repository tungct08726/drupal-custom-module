<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Http\Services\Product\ProductService;

use App\Product;
class MainController extends Controller
{

    protected $product;

    public function __construct(ProductService $product){
        $this->product = $product; 
    }


    public function admin()
    {
        return view('admin.home',[
            'title' => "Admin hdwebsoft"
        ]);    
    }

    public function index()
    {
        return view('main',[
            'title' => "Home"
        ]);
    }
    public function loadProduct(Request $request)
    {
        $page= $request->input('page',0);
        $result= $this->product->load($page);

        if (count($result) != 0) {
            $html = view('product.product_list',['products'=>$result])->render();
            return response()->json([
                'html' => $html
            ]);              
        }
        return response()->json([
            'html' => ''
        ]);          
    }


    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logOut(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }

}
