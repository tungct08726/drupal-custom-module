<?php

namespace App\Http\Services\Post;
use App\Post;
use App\Category;
use Illuminate\Support\Facades\Session;

class PostService
{
    public function create($request){
        $post= $request->input();
        try{
            $post = Post::create([
                'name' => (string) $request->input('name'),
                'thumb' => (string) $request->input('thumb'),
                'description' => (string) $request->input('description'),
                'content' => (string) $request->input('content'),
                'slug' => (string) $request->input('slug'),
                'active' => (int) $request->input('active'),
                'voucher_enable' => (int) $request->input('voucher_enable'),
                'voucher_quantity' => (int) $request->input('voucher_quantity'),
            ]);
            $post->categories()->sync($request->input('category'));
            Session::flash('success','Post Created');
            //$product->Categories()->sync([1, 3, 4]);
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;
    }
    public function update($request, $post)
    {

        try{

            $post->name = (string) $request->input('name');
            $post->thumb = (string) $request->input('thumb');
            $post->description = (string) $request->input('description');
            $post->content = (string) $request->input('content');
            $post->slug = (string) $request->input('slug');
            $post->active = (int) $request->input('active');
            $post->voucher_enable = (int) $request->input('voucher_enable');
            $post->voucher_quantity = (int) $request->input('voucher_quantity');
            $post->save();
            $post->categories()->sync($request->input('category'));
            Session::flash('success',' Post Updated ');
            
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;

    }
    public function destroy($request){
        $id =$request->input('id');

        $post = Post::where('id','=',$id)->first();
        if ($post) {
            return Post::where('id','=',$id)->delete();
        }
        return false;
    }
    public function getAll($request){
        
        
        if ($request->input('category_id') != null) {
            $query = Category::where('id',$request->input('category_id'))->first();
            $category_post= $query->posts();
            return $category_post
            ->orderBy('id','desc')
            ->paginate(15)
            ->withQueryString();
        }


        return Post::orderBy('id','desc')->paginate(15);
    }

}
