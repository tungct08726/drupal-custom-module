<?php

namespace App\Http\Services\Category;
use App\Category;
use Illuminate\Support\Facades\Session;

class CategoryService
{
    public function create($request){
        $cate= $request->input();  
        try{
            Category::create([
                'name' => (string) $request->input('name'),
                'parent_id' => (int) $request->input('parent_id'),
                'description' => (string) $request->input('description'),
                'content' => (string) $request->input('content'),
                'slug' => (string) $request->input('slug'),
                'active' => (int) $request->input('active'),
            ]);

            Session::flash('success','Cate Created');
            
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;
    }
    public function update($request, $cate)
    {

        try{

            $cate->name = (string) $request->input('name');
            if ($cate->id != (int) $request->input('parent_id')) {
                $cate->parent_id = (int) $request->input('parent_id');
            }
            
            $cate->description = (string) $request->input('description');
            $cate->content = (string) $request->input('content');
            $cate->slug = (string) $request->input('slug');
            $cate->active = (int) $request->input('active');
            $cate->save();

            Session::flash('success','~ Category Updated ~');
            
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;

    }
    public function destroy($request){
        $id =$request->input('id');

        $cate = Category::where('id','=',$id)->first();
        if ($cate) {
            return Category::where('id','=',$id)->orWhere('parent_id','=',$id)->delete();
        }
        return false;
    }

    public function getParent(){
        return Category::where('parent_id','=',0)->get();
    }
    public function getAll(){
        return Category::where('active',1)->orderBy('id','desc')->get();
    }
    public function getId($id){
        return Category::where('id','=',$id)->where('active',1)->firstOrFail();
    }
    public function getProduct($cate,$request){
        $query = $cate->posts()->where('active',1);
       
        return $query
        ->orderBy('id','desc')
        ->paginate(12);
    }

}
