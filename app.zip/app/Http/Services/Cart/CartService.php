<?php

namespace App\Http\Services\Cart;
use App\Product;
use App\Customer;
use App\Cart;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

use App\Jobs\SendMail;

class CartService
{
	public function create($request){
		$qty= (int)$request->input('num_product');
		$product_id= (int)$request->input('product_id');

		if ($qty<=0 || $product_id <=0) {
			Session::flash('error','~ Số Lượng Hoặc Sản Phẩm Không Chính Xác ~');
			return false;
		}

		$carts = Session::get('cart');
		if (is_null($carts)) {
			Session::put('cart',[
				$product_id =>$qty
			]);

			return true;
		}
		//kiểm tra trong mảng có key này hay chưa -> ktra trong giỏ hàng đã có id này chưa
		$exist = Arr::exists($carts,$product_id);
		if ($exist) {
			$carts[$product_id]= $carts[$product_id] + $qty;
			Session::put('cart',$carts);			
			return true;
		}
			$carts[$product_id]= $qty;
			Session::put('cart',$carts);
		return true;
	}

	public function update($request){

		foreach ($request->input('num_product') as $key => $value) {
			if ($value <= 0) {
				Session::flash('error','~ Số Lượng Sản Phẩm Không Chính Xác ~');
				return false;
			}
		}
			Session::put('cart',$request->input('num_product'));
			return true;		
	}

	public function remove($id){

		$carts = Session::get('cart');
		unset($carts[$id]);	
		Session::put('cart',$carts);
		return true;
	}

	public function getProduct(){
		$carts = Session::get('cart');
		if (is_null($carts)) {
			return [];
		}	
		$productId = array_keys($carts);
		return Product::select('id','name','thumb','price','price_sale')
		->where('active',1)
		->whereIn('id',$productId)
		->get();	
	}

	public function addCart($request){
		try{
			//nếu try bị lỗi sẽ back lại tất cả câu lệnh
			DB::beginTransaction();

			$carts = Session::get('cart');
			if (is_null($carts)) {
				return false;
			}	

			$customer = Customer::create([
				'name' => $request->input('name'),
				'email' => $request->input('email'),
				'phone' => $request->input('phone'),
				'address' => $request->input('address'),
				'content' => $request->input('content'),
			]);

			$this->infoProductCart($carts, $customer->id);
			DB::commit();
			
			Session::forget('cart');

			##Queue
			SendMail::dispatch($request->input('email'))->delay(now()->addSeconds(5));

			Session::flash('success','~ Complete ~');
		}catch(\Exception $err){
			DB::rollBack();
			Session::flash('error','~ Đặt Hàng Lỗi Rồi ~');
			return false;
		}
		return true;
	}
	protected function infoProductCart($carts, $customer_id){
			$productId = array_keys($carts);
			$products = Product::select('id','name','thumb','price','price_sale')
			->where('active',1)
			->whereIn('id',$productId)
			->get();
			$data=[];
			foreach ($products as $key => $value) {
				$data[]=[
					'customer_id' => $customer_id,
					'product_id' =>$value->id,
					'qty' => $carts[$value->id],
					'price' =>$value->price_sale !=0 ? $value->price_sale:$value->price
				];
			}
			return Cart::insert($data);
			
	}

}