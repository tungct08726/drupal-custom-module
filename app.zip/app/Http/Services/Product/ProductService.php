<?php

namespace App\Http\Services\Product;
use App\Product;
use App\Menu;
use Illuminate\Support\Facades\Session;

class ProductService
{
    const limit= 8;
    #Admin

    protected function isValidPrice($request){
        if ($request->input('price') != 0 && $request->input('price_sale') != 0 &&
            $request->input('price_sale') >= $request->input('price') ) {
            Session::flash('error','Giá giảm phải nhỏ hơn giá gốc');
            return false;
        }

        if ($request->input('price') == 0 && $request->input('price_sale') != 0 ) {
            Session::flash('error','Vui lòng nhập giá gốc');
            return false;
        }        
        return true;
    }

    public function create($request){
        $isValidPrice = $this->isValidPrice($request);
        if ($isValidPrice == false) return false;

        try{

            $request->except(['file','file2','_token']);
            //Product::create($request->all());

            Product::create([
                'name' => (string) $request->input('name'),
                'thumb' => (string) $request->input('thumb'),
                'photos' =>  json_encode($request->input('photos')),
                'description' => (string) $request->input('description'),
                'content' => (string) $request->input('content'),
                'menu_id' => (string) $request->input('menu_id'),
                'price' => (int) $request->input('price'),
                'price_sale'=> (int) $request->input('price_sale'),
                'active' => (int) $request->input('active'),
                'slug' => (string) $request->input('slug'),
                'active' => (int) $request->input('active'),
            ]);

            Session::flash('success','~ Product Created ~');
            
        }catch(\Exception $err){
            Session::flash('error','Thêm sản phẩm lỗi , có lẽ đường link (slug) bị trùng');
            //Session::flash('error',$err->getMessage());$product->Categories()->sync([1, 3, 4]);
            return false;
        }
        return true;
    }
    public function update($product,$request)
    {
        $isValidPrice = $this->isValidPrice($request);
        if ($isValidPrice == false) return false;
        try{

            $request->except(['file','_token']);

                $product->name = (string) $request->input('name');
                $product->thumb = (string) $request->input('thumb');
                $product->photos =  json_encode($request->input('photos'));
                $product->description = (string) $request->input('description');
                $product->content = (string) $request->input('content');
                $product->menu_id = (string) $request->input('menu_id');
                $product->price = (int) $request->input('price');
                $product->price_sale = (int) $request->input('price_sale');
                $product->active = (int) $request->input('active');        
                $product->slug = (string) $request->input('slug');

            $product->save();
            
            Session::flash('success','~ Product Updated ~');            
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;

    }
    public function destroy($request){
        $id =$request->input('id');

        $product = Product::where('id','=',$id)->first();
        if ($product) {
            return Product::where('id','=',$id)->delete();
        }
        return false;
    }

    ##

    ## View

    public function getCategory(){
        return Menu::where('active',1)->get();
    }
    public function getAll(){
        return Product::with('menu')->orderBy('id','desc')->paginate(15);
    }

    public function show(){
        return Product::with('menu')->where('active',1)->take(self::limit)->orderBy('id','desc')->get();
    }
    public function getProductDetail($id,$request){
        return Product::with('menu')
        ->where('id',$id)
        ->where('active',1)->firstOrFail();
    }
    public function getProductRelate($id,$request,$menu_id){
        return Product::with('menu')
        ->where('menu_id',$menu_id)
        ->where('id','<>',$id)
        ->where('active',1)
        ->inRandomOrder()
        ->take(10)
        ->get();
    }

    public function load($page = null){
        return Product::
        when($page != null, function ($query) use ($page){

            $query->skip( $page * self::limit);
        })
        ->take(self::limit)
        ->orderBy('id','desc')
        ->get();
    }

}
