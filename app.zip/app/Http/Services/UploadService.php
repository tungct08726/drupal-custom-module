<?php

namespace App\Http\Services;
use App\Product;
use App\Menu;
use Illuminate\Support\Facades\Session;

class UploadService
{
	public function store($request){
		if ($request->hasFile('file')) {
			try{
				$name = $request->file('file')->getClientOriginalName();
				$pathFull='uploads/'. date('Y/m');
				$path=$request->file('file')->storeAs(
					'public/'. $pathFull, $name
				);				
				return '/storage/' . $pathFull . '/' . $name;
			}catch(\Exception $err){
			    return false;
			}
			
		}
	}

	public function store2($request){
		if ($request->hasFile('file2')) {
			try{
				$name = $request->file('file2')->getClientOriginalName();
				$pathFull='uploads/photos';
				$path=$request->file('file2')->storeAs(
					'public/'. $pathFull, $name
				);				
				return '/storage/' . $pathFull . '/' . $name;
			}catch(\Exception $err){
			    return false;
			}
			
		}
	}

}
