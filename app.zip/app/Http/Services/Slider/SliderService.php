<?php

namespace App\Http\Services\Slider;
use App\Slider;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Facades\Storage;
class SliderService
{
    public function create($request){
        try{

            $request->except(['file','_token']);
            Slider::create($request->all());

            Session::flash('success','~ Slider Created ~');
            
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;
    }
    public function update($request, $slider)
    {

        try{

            $request->except(['file','_token']);

            $slider->fill($request->input());
            $slider->save();
            
            Session::flash('success','~ Slider Updated ~');            
        }catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;
    }
    public function destroy($request){
        $id =$request->input('id');

        $slider = Slider::where('id','=',$id)->first();
/** Xóa ảnh trong uploads khi xóa slide
        $path= str_replace('storage', 'public', $slider->thumb);
        Storage::delete($path);
*/
        if ($slider) {
            return Slider::where('id','=',$id)->delete();
        }
        return false;
    }

    public function getAll(){
        return Slider::orderBy('id','desc')->paginate(15);
    }
    public function show(){
        return Slider::where('active',1)->orderBy('sort_by','desc')->take(3)->get();
    }    
}
